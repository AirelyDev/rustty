# Delta verification findings (Mac runner) at 26d23100b

Provisional ids N544+ (controller renumbering: N640 -> N542, N641 -> N543).

## N544 (provisional): G-SKIP RED on the FX4 oniguruma first-use test
- Gate: G-SKIP (`python3 .port/tools/gates/check_silent_skips.py`, a ci.sh HARD gate). Static check, host independent.
- Output: `RED  LOOP  crates/rustty-core/src/surface/tests.rs:2284 [concurrent_derived_config_link_regexes_and_ensure_init_do_not_race]: every assertion is inside a loop / combinator over a probe result that may be empty`
- Cause: the test was added by bf5f8457c (FX4, N622) after the last full ci.sh evidence, and G-SKIP was not rerun at the final head.
- Not fixed here (runner rules).
