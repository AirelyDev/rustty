#!/bin/sh
# Run each live GTK KAT alone under the headless sway (Wayland) session.
cd ~/rustty
export XDG_RUNTIME_DIR=/tmp/xdg-runtime-$(id -u) WAYLAND_DISPLAY=wayland-1 GDK_BACKEND=wayland LIBGL_ALWAYS_SOFTWARE=1
unset DISPLAY; export SWAYSOCK=$(ls $XDG_RUNTIME_DIR/sway-ipc.*.sock | head -1)
FEAT="${FEAT:-gtk}"
while read bin name; do
  [ -z "$bin" ] && continue
  out=/tmp/live-$bin-$name.log
  timeout 300 dbus-run-session -- cargo test -q -p rustty-apprt --features "$FEAT" --test $bin -- --ignored --exact $name > $out 2>&1
  rc=$?
  if grep -q "1 passed" $out; then r=PASS; elif [ $rc = 124 ]; then r=TIMEOUT; else r="FAIL($rc)"; fi
  echo "$r $bin::$name"
done
